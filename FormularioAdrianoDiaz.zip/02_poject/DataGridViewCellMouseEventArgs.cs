﻿namespace _02_poject
{
    internal class DataGridViewCellMouseEventArgs
    {
    }
}